### Visual Studio Project Demo

Demonstrates a simple project

---